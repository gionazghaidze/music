@echo off
title Melomix - Music Recommender
echo ========================================================
echo   Melomix - მუსიკების შემომთავაზებელი & ამრჩევი
echo ========================================================
echo სერვერი ირთვება...
echo ბრაუზერი ავტომატურად გაიხსნება მისამართზე: http://localhost:8000/preview.html
echo.
start http://localhost:8000/preview.html
python -m http.server 8000
pause

